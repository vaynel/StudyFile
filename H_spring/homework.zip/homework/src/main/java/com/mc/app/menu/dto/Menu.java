package com.mc.app.menu.dto;

import lombok.Data;

@Data
public class Menu {
	
	private String menu;

	
}
