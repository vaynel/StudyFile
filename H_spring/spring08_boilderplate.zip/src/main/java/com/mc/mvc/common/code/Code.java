package com.mc.mvc.common.code;

public enum Code {
	
	STMP_FROM("ssp04041@naver.com"),
	DOMAIN("http://localhost:8081");
	
	
	public String desc;
	
	Code(String desc) {
		this.desc=desc;
	}
	
	@Override
	public String toString() {
		return desc;
	}
	
}
