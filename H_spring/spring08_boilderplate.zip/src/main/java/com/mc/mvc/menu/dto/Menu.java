package com.mc.mvc.menu.dto;

public class Menu {
	
	private String menu;
	
	public Menu() {
		// TODO Auto-generated constructor stub
	}


	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	
	@Override
	public String toString() {
		return "Menu [menu=" + menu + "]";
	}
	

}
